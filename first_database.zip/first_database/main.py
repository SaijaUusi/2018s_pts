# main.py
from flask import flash, render_template, request, redirect
from sqlalchemy import select
 
from db_setup import init_db, db_session
from app import app
from forms import QuestionForm, QuestionSearchForm
from models import Question
from tables import Results

init_db()
  
@app.route('/', methods=['GET', 'POST'])
def index():
    Question.__table__.create(db_session.bind)
    return "table made!"
    #return render_template('index.html', form=request.form)

@app.route('/search', methods=['GET', 'POST'])
def search():
    search = QuestionSearchForm(request.form)
    if request.method == 'POST':
        return searchQuestions(search)

    return render_template('search.html', form=search)

def searchQuestions(form):
    question = db_session.query(Question).filter_by(id=form.questionID.data).first()
    flash("Question with ID " + str(question.id) + ": " + (question.questionText))
    return redirect('/search')

@app.route('/printQuestions')
def printAddedQuestions():
    results = []

    qry = db_session.query(Question)
    results = qry.all()

    return render_template('results.html', table=results)
 
 
@app.route('/addNewQuestion', methods=['GET', 'POST'])
def addNewQuestion():
    form = QuestionForm(request.form)

    if request.method == 'POST' and form.validate():
        saveQuestion(form)
        flash('Question saved successfully!')
        return redirect('/')
 
    return render_template('new_question.html', form=form)
 
def saveQuestion(form):
    question = Question()
    question.questionText = form.questionText.data
    question.answerType = form.answerType.data
 
    db_session.add(question)
 
    # commit the data to the database
    db_session.commit()