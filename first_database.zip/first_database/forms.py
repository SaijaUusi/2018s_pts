# forms.py
 
from wtforms import Form, StringField, SelectField
 
class QuestionSearchForm(Form):
    questionID = StringField('Question ID')

class QuestionForm(Form):
    answer_types = [('Stars', 'Stars'),
                   ('Thumbs up/down', 'Thumbs up/down'),
                   ('Smiley faces', 'Smiley faces'),
                   ('Text field', 'Text field'),
                   ('Selfie', 'Selfie')
                   ]
    questionText = StringField('Question text')
    answerType = SelectField('Answer type', choices=answer_types)