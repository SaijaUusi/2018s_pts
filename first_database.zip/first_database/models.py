# models.py 
 
from app import db

class Question(db.Model):
    __tablename__ = "questions"
 
    id = db.Column(db.Integer, primary_key=True)
    questionText = db.Column(db.String)
    answerType = db.Column(db.String)
 
    def __repr__(self):
        return "<Question: {}>".format(self.name)