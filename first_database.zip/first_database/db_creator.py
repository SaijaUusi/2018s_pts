from sqlalchemy import create_engine, ForeignKey
from sqlalchemy import Column, Date, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, backref

engine = create_engine('sqlite:///llb.db', echo=True)
Base = declarative_base()

class Question(Base):
    __tablename__ = "questions"
 
    id = db.Column(db.Integer, primary_key=True)
    questionText = db.Column(db.String)
    answerType = db.Column(db.String)
 
    def __repr__(self):
        return "<Question: {}>".format(self.name)
        
# create tables
Base.metadata.create_all(engine)